import 'package:flutter/material.dart';
class LogInScreen extends StatefulWidget {
  const LogInScreen({Key? key}) : super(key: key);

  @override
  State<LogInScreen> createState() => _LogInScreenState();
}

class _LogInScreenState extends State<LogInScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          SizedBox(height: 52,width: MediaQuery.of(context).size.width,),
          SizedBox(
              height: 57,
              width: 201,
              child: Image.asset('images/okpi.png',fit: BoxFit.fill,)),
        ],
      ),
    );
  }
}
