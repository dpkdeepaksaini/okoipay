import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
class Chat1Tab2 extends StatefulWidget {
  const Chat1Tab2({Key? key}) : super(key: key);

  @override
  State<Chat1Tab2> createState() => _Chat1Tab2State();
}

class _Chat1Tab2State extends State<Chat1Tab2> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('payment screen')
      ),
    );
  }
}
