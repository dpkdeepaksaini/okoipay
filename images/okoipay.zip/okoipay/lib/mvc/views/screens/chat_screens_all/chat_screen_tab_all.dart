import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:okoipay/mvc/views/screens/chat_screens_all/chat2_screen.dart';

class Chat1Tab1 extends StatefulWidget {
  const Chat1Tab1({Key? key}) : super(key: key);

  @override
  State<Chat1Tab1> createState() => _Chat1Tab1State();
}

class _Chat1Tab1State extends State<Chat1Tab1> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        height: MediaQuery.of(context).size.height,
        width: MediaQuery.of(context).size.width,
        child: SingleChildScrollView(
          child: Container(
            child: Column(
              children: [
                InkWell(
                  onTap: (){
                    Navigator.of(context).push(MaterialPageRoute(builder: (context){
                      return ChatScreen2();
                    }));
                  },
                  child: Column(
                    children: [
                      ListTile(
                        leading: CircleAvatar(
                          backgroundImage: AssetImage('images/dp2.png'),
                          radius: 28.5,
                        ),
                        title: Text('Vijay'),
                        subtitle: Row(
                          children: [
                            Icon(
                              Icons.currency_rupee,
                              size: 12,
                            ),
                            Text('100 recevived',
                                style: GoogleFonts.getFont(
                                  'Inter',
                                  fontSize: 12,
                                  fontWeight: FontWeight.w500,
                                  color: Colors.black.withOpacity(0.5),
                                ))
                          ],
                        ),
                        trailing: Text(
                          '14/10/22',
                          style: GoogleFonts.getFont('Inter',
                              fontWeight: FontWeight.w500, fontSize: 12),
                        ),
                      ),
                      Divider(),
                    ],
                  ),
                ),
                Column(
                  children: [
                    ListTile(
                      leading: CircleAvatar(
                        backgroundImage: AssetImage('images/dp1.png'),
                        radius: 28.5,
                      ),
                      title: Text('Pawan'),
                      subtitle: Row(
                        children: [
                          Icon(
                            Icons.currency_rupee,
                            size: 12,
                          ),
                          Text('180 recevived',
                              style: GoogleFonts.getFont(
                                'Inter',
                                fontSize: 12,
                                fontWeight: FontWeight.w500,
                                color: Colors.black.withOpacity(0.5),
                              ))
                        ],
                      ),
                      trailing: Text(
                        '06/10/22',
                        style: GoogleFonts.getFont('Inter',
                            fontWeight: FontWeight.w500, fontSize: 12),
                      ),
                    ),
                    Divider(),
                  ],
                ),
                Column(
                  children: [
                    ListTile(
                      leading: CircleAvatar(
                        backgroundImage: AssetImage('images/dp1.png'),
                        radius: 28.5,
                      ),
                      title: Text('Rajesh Kumar'),
                      subtitle: Row(
                        children: [
                          Icon(
                            Icons.currency_rupee,
                            size: 12,
                          ),
                          Text('1 send',
                              style: GoogleFonts.getFont(
                                'Inter',
                                fontSize: 12,
                                fontWeight: FontWeight.w500,
                                color: Colors.black.withOpacity(0.5),
                              ))
                        ],
                      ),
                      trailing: Text(
                        '01/10/22',
                        style: GoogleFonts.getFont('Inter',
                            fontWeight: FontWeight.w500, fontSize: 12),
                      ),
                    ),
                    Divider(),
                  ],
                ),
                Column(
                  children: [
                    ListTile(
                      leading: CircleAvatar(
                        backgroundImage: AssetImage('images/dp2.png'),
                        radius: 28.5,
                      ),
                      title: Text('Vijay'),
                      subtitle: Row(
                        children: [
                          Icon(
                            Icons.currency_rupee,
                            size: 12,
                          ),
                          Text('100 recevived',
                              style: GoogleFonts.getFont(
                                'Inter',
                                fontSize: 12,
                                fontWeight: FontWeight.w500,
                                color: Colors.black.withOpacity(0.5),
                              ))
                        ],
                      ),
                      trailing: Text(
                        '14/10/22',
                        style: GoogleFonts.getFont('Inter',
                            fontWeight: FontWeight.w500, fontSize: 12),
                      ),
                    ),
                    Divider(),
                  ],
                ),
                Column(
                  children: [
                    ListTile(
                      leading: CircleAvatar(
                        backgroundImage: AssetImage('images/dp1.png'),
                        radius: 28.5,
                      ),
                      title: Text('Pawan'),
                      subtitle: Row(
                        children: [
                          Icon(
                            Icons.currency_rupee,
                            size: 12,
                          ),
                          Text('180 recevived',
                              style: GoogleFonts.getFont(
                                'Inter',
                                fontSize: 12,
                                fontWeight: FontWeight.w500,
                                color: Colors.black.withOpacity(0.5),
                              ))
                        ],
                      ),
                      trailing: Text(
                        '06/10/22',
                        style: GoogleFonts.getFont('Inter',
                            fontWeight: FontWeight.w500, fontSize: 12),
                      ),
                    ),
                    Divider(),
                  ],
                ),
                Column(
                  children: [
                    ListTile(
                      leading: CircleAvatar(
                        backgroundImage: AssetImage('images/dp1.png'),
                        radius: 28.5,
                      ),
                      title: Text('Rajesh Kumar'),
                      subtitle: Row(
                        children: [
                          Icon(
                            Icons.currency_rupee,
                            size: 12,
                          ),
                          Text('1 send',
                              style: GoogleFonts.getFont(
                                'Inter',
                                fontSize: 12,
                                fontWeight: FontWeight.w500,
                                color: Colors.black.withOpacity(0.5),
                              ))
                        ],
                      ),
                      trailing: Text(
                        '01/10/22',
                        style: GoogleFonts.getFont('Inter',
                            fontWeight: FontWeight.w500, fontSize: 12),
                      ),
                    ),
                    Divider(),
                  ],
                ),
                Column(
                  children: [
                    ListTile(
                      leading: CircleAvatar(
                        backgroundImage: AssetImage('images/dp2.png'),
                        radius: 28.5,
                      ),
                      title: Text('Vijay'),
                      subtitle: Row(
                        children: [
                          Icon(
                            Icons.currency_rupee,
                            size: 12,
                          ),
                          Text('100 recevived',
                              style: GoogleFonts.getFont(
                                'Inter',
                                fontSize: 12,
                                fontWeight: FontWeight.w500,
                                color: Colors.black.withOpacity(0.5),
                              ))
                        ],
                      ),
                      trailing: Text(
                        '14/10/22',
                        style: GoogleFonts.getFont('Inter',
                            fontWeight: FontWeight.w500, fontSize: 12),
                      ),
                    ),
                    Divider(),
                  ],
                ),
                Column(
                  children: [
                    ListTile(
                      leading: CircleAvatar(
                        backgroundImage: AssetImage('images/dp1.png'),
                        radius: 28.5,
                      ),
                      title: Text('Pawan'),
                      subtitle: Row(
                        children: [
                          Icon(
                            Icons.currency_rupee,
                            size: 12,
                          ),
                          Text('180 recevived',
                              style: GoogleFonts.getFont(
                                'Inter',
                                fontSize: 12,
                                fontWeight: FontWeight.w500,
                                color: Colors.black.withOpacity(0.5),
                              ))
                        ],
                      ),
                      trailing: Text(
                        '06/10/22',
                        style: GoogleFonts.getFont('Inter',
                            fontWeight: FontWeight.w500, fontSize: 12),
                      ),
                    ),
                    Divider(),
                  ],
                ),
                Column(
                  children: [
                    ListTile(
                      leading: CircleAvatar(
                        backgroundImage: AssetImage('images/dp1.png'),
                        radius: 28.5,
                      ),
                      title: Text('Rajesh Kumar'),
                      subtitle: Row(
                        children: [
                          Icon(
                            Icons.currency_rupee,
                            size: 12,
                          ),
                          Text('1 send',
                              style: GoogleFonts.getFont(
                                'Inter',
                                fontSize: 12,
                                fontWeight: FontWeight.w500,
                                color: Colors.black.withOpacity(0.5),
                              ))
                        ],
                      ),
                      trailing: Text(
                        '01/10/22',
                        style: GoogleFonts.getFont('Inter',
                            fontWeight: FontWeight.w500, fontSize: 12),
                      ),
                    ),
                    Divider(),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
