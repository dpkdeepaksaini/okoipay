import 'package:flutter/material.dart';

import 'mvc/views/screens/chat_screens_all/chat_screen.dart';
import 'mvc/views/screens/splash_or_on_bording_screens/Splash_screen_1.dart';
import 'mvc/views/screens/splash_or_on_bording_screens/onboarding1.dart';
 void main(){
   runApp(const MyApp());
 }
class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home:ChatScreen1() ,
    );
  }
}


