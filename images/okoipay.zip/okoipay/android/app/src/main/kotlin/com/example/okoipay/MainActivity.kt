package com.example.okoipay

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
